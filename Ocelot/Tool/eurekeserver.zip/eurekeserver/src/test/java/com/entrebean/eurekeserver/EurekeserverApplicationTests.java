package com.entrebean.eurekeserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekeserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
