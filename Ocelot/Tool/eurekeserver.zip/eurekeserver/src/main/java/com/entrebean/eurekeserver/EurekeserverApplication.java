package com.entrebean.eurekeserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekeserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekeserverApplication.class, args);
	}

}
